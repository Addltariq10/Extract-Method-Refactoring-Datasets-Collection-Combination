package gr.uom.java.ast.visualization;

public interface VisualizationData {

}
