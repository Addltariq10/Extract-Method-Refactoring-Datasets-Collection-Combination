
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import parsing.QueryStructure;
import partialMarking.TestPartialMarking;
import parsing.Node;
import database.*;
import evaluation.FailedDataSetValues;
import com.google.gson.Gson;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import com.google.gson.reflect.TypeToken;
import testDataGen.PopulateTestDataGrading;
import util.DataSetValue;
import util.DatabaseConnectionDetails;
/**
 * Servlet implementation class GuestStudentTestCase
 */
@WebServlet("/GuestStudentTestCase")
public class GuestStudentTestCase extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(StudentTestCase.class.getName());   
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GuestStudentTestCase() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Write new method here
		boolean isForView = false;
		HttpSession session=request.getSession(false);
		if (session.getAttribute("LOGIN_USER") == null) {
			response.sendRedirect("index.jsp?TimeOut=true");
			return;
		}


		Connection dbCon = null, testcon = null;
		boolean isViewGradedAssignment = false;
		int assignment_id=Integer.parseInt(request.getParameter("assignment_id"));
		int question_id=Integer.parseInt(request.getParameter("question_id")); 
		int query_id=1;
		String course_id = (String) request.getSession().getAttribute("context_label");
		String user_id=request.getParameter("user_id");
		String status = request.getParameter("status");

		int maxMarks = Integer.parseInt(request.getParameter("maxMarks"));

		//Instead of getting it from sessin, get it from student table - tajudgement attribute
		//If evaluation status of the assignment is true, then the assignment is evaluated, set this label to true.

		if(session.getAttribute("displayTestCase") != null && Boolean.valueOf(session.getAttribute("displayTestCase").toString()) == true){
			dbCon = (Connection) session.getAttribute("dbConn");
			testcon = (Connection) session.getAttribute("testConn");
			session.setAttribute("displayTestCase", false);
		}
		/*segment 32-42 : begins*/	//1 stmt extra 	//MAtch
		//Get connections if they are closed
		if(testcon==null){
			/// 4 checkConnection	start GSTCRefactor#1
			try {
				DatabaseConnectionDetails dbConnDetails = (new util.DatabaseConnection()).getTesterConnection(assignment_id);
				testcon = dbConnDetails.getTesterConn();
				if(testcon!=null){
					logger.log(Level.FINE,"Connected successfullly");
				}
			}catch (Exception ex) {
				logger.log(Level.SEVERE,"SQLException: " + ex.getMessage());
				throw new ServletException(ex);
			}	
		}
		//end GSTCRefactor#1 		
		/*segment 32-42 : ends*/ 		
		logger.log(Level.FINE,"Assignment_id :"+assignment_id);
		logger.log(Level.FINE,"Question_id :"+question_id);
		logger.log(Level.FINE,"User id : "+user_id);
		if(dbCon == null){ 
			dbCon=(Connection) session.getAttribute("dbConnection");
		}
		/*segment48-57 : begins*/		 	//MAtch with 1 extra stmt
		if(dbCon==null)//Nd-48
		{
			/// 4 checkConnection start GSTCRefactor#2
			try {
				// Class.forName("org.postgresql.Driver");
				dbCon = (new DatabaseConnection()).dbConnection();
				if(dbCon!=null){
					logger.log(Level.FINE,"Connected successfullly");
					//session.setAttribute("TestConnection", testcon); 
				}
			}catch (Exception ex) {
				logger.log(Level.SEVERE,"SQLException: " + ex.getMessage(),ex);
				throw new ServletException(ex);
			}
			//end GSTCRefactor#2	    		
		}
		/*segment48-57: ends*/		

		HashSet<String> hs=new HashSet<String>();
		response.setContentType("text/html;charset=UTF-8");



		String out_assignment="";//part of segment 68-77		//belongs to GSTCRefactor#3
		out_assignment += "<link rel=\"stylesheet\" href=\"../highlight/styles/xcode.css\">  "+
				"<link rel=\"stylesheet\" href=\"../highlight/styles/default.css\">" +
				"<script src=\"../highlight/highlight.pack.js\"></script> "
				+"<script type=\"text/javascript\">" 
				+  "hljs.initHighlighting.called = false;hljs.initHighlighting();" 
				+"function toggleRefTables(id){"
				+"$(id).toggle();"

			+"if($(id).parent().children()[0].innerHTML==\"View Referenced Tables\"){"
			+"$(id).parent().children()[0].innerHTML=\"Hide Referenced Tables\";"
			+"}"
			+"else{"
			+"$(id).parent().children()[0].innerHTML=\"View Referenced Tables\";"
			+"}"
			+"}"+" $(document).on('click','#showAnswer',function (event) { event.preventDefault();$('#answer').show(); $('#showAnswer').hide(); });"
			+" $(document).on('click','#passedDataSets',function (event) " +
			"{ event.preventDefault();$('#ShowPassedDataSets').show(); " +
			"$('html,body').animate({ scrollTop: $('#ShowPassedDataSets').offset().top-10});     " +
			"});"
			+"</script>";//part of segment 68-77	//Review

		String studAnswer = CommonFunctions.decodeURIComponent(request.getParameter("query"));
		FailedDataSetValues failedDS = (FailedDataSetValues)session.getAttribute("failedDS");

		/*segment68-77 : begins */	 /// 4 checkForError start GSTCRefactor#3	//MAtch
		out_assignment += "<div class=\"fieldset\"><legend>Result</legend><fieldset>"+ 
				"<div><div class=\"info\">"+
				"<h2>Question: "+question_id+"</h2>"+
				"</div>"   
				+"<p align=\"left\"> <strong> Your Answer: </strong>"+ "<pre><code class=\"sql\">"+CommonFunctions.encodeHTML(CommonFunctions.decodeURIComponent(request.getParameter("query")))+"</code></pre></p>";
		if(status.equals("Error")){
			out_assignment += "<div style = 'font-weight: bold'>Status: <label style = 'color:red;'>Error</label></div>";
			out_assignment += "<br/><div style = 'font-weight:bold'>Message: <span style='font-weight:normal;'>Sorry, your query could not be executed. Please check the syntax and try again.</span></div>";
			String message = request.getParameter("Error");

			if(!message.isEmpty()){
				out_assignment += "<br/><div style = 'font-weight:bold'> Details: <span style='font-weight:normal;'>" + CommonFunctions.decodeURIComponent(message) + "</span></div>";
			}
		}
		//end GSTCRefactor#3		
		/*segment68-77*/		


		/// 4 queryResultAction start GSTCRefactor#4
		/*segment78-98: begins*/ 		//MAtch
		int marks = Integer.parseInt(request.getParameter("marks"));	//moved here as it is used here
		Boolean learningMode = false;//moved here as it is used here
		if(status.equals("NoDataset")){
			out_assignment += "<div style = 'font-weight: bold'>Status: <label style = 'color:red;'>Error</label></div>";
			out_assignment += "<br/><div style = 'font-weight:bold'>Message: <span style='font-weight:normal;'>Not answered</span></div>";
			String message = "Please answer the question.";

			if(!message.isEmpty()){
				//out_assignment.println("<br/><div style = 'font-weight:bold'> Error Message: <span style='font-weight:normal;'>" + CommonFunctions.decodeURIComponent(message) + "</span></div>");
			}
		} 
		else if(!learningMode && status.equals("Failed")){
			out_assignment += "<div style = 'font-weight: bold'>Status: <label style = 'color:red'>Incorrect  </label><label style='font-weight:normal;'> - Your query has failed.</label> </div>";
			out_assignment += "<br/><div style = 'font-weight: bold'>Marks awarded: <label style = 'color:red;'>"+marks+"</label><label style='font-weight:normal;font-size:12;'> - Details shown with correct answer</label></div>"; 
			//out_assignment.println("<div style = 'font-weight: bold'>Status: <label style = 'color:red'>Incorrect  </label><label style='font-weight:normal;'> Some parsing error occurred. Please check the answer.</label> </div>");
		}  
		else if(status.equals("passed")){
			//This part of code wont be reached. This can be removed after proper testing
			out_assignment += "<div style = 'font-weight: bold'>Status: <label style = 'color:green'> Ok </label><label style='font-weight:normal;'> - Your query has passed the test cases.</label> </div>";
		}
		else if(status.equals("Failed")){
			out_assignment += "<br/><div style = 'font-weight: bold'>Status: <label style = 'color:red;'>Incorrect</label></div>";
			out_assignment += "<br/><div style = 'font-weight: bold'>Marks awarded: <label style = 'color:red;'>"+marks+"</label><label style='font-weight:normal;font-size:12;'> - Details shown with correct answer</label></div>"; 
		}
		out_assignment += "<br/>";
		//end GSTCRefactor#4		
		/*segment78-98: ends*/	
		if(status == null || (status != null && status.isEmpty()) || (status != null && status.equalsIgnoreCase("error"))){
			status ="Incorrect";
		}
		if(status.equals("Failed")){
			ArrayList <String>instructorQueries = new ArrayList<String>(); 
			String out = "";
			// Show instructor answer and partial marks awarded and then on click of I give up link, show the partial mark details and DS0.

			/*segment105, 107-146 : begins*/ // match /// 4 showDatasets 	start GSTCRefactor#5	
			try(PreparedStatement stment=dbCon.prepareStatement("select sql from xdata_instructor_query where course_id = ? and assignment_id=? and question_id=? ")){
				stment.setString(1, course_id);
				stment.setInt(2, assignment_id);
				stment.setInt(3, question_id); 
				out_assignment += "<div>";
				//out_assignment.println("<a class='showhidelink' href = 'javascript:void(0);' onclick=\"toggleInstrAnswer('#answer')\">I give it up! Show me the answer</a>");

				//Show Failed Datasets, student and instructor result against failed DS.
				out_assignment += "<h3><a href='#passedDataSets' id='passedDataSets' style='color:green;'>View passed datasets</a></h3>";
				out_assignment += this.showFailedDataSets(failedDS,testcon,dbCon,assignment_id,question_id,course_id);

				out_assignment += "<br/><input type='button' style='float:center;display:block;color:blue;font-weight:bold;background-color:#blue;'  id='showAnswer' value='I give it up! Show me the answer'/><br/>";


				out_assignment += this.showPassedDataSets(failedDS,testcon,dbCon,assignment_id,question_id,course_id);

				out_assignment += "<div class='detail' id='answer'>";


				/*segment118-131 : begins*/	 /// 3		//NotMatch
				try(ResultSet rs2 = stment.executeQuery()){
					while(rs2.next()){
						out = "<p align=\"left\"> <strong>Instructor's Answer: </strong>";
						out += "<pre><code class=\"sql\">"+CommonFunctions.encodeHTML(rs2.getString("sql"))+"</code></pre>";
						instructorQueries.add(rs2.getString("sql"));
						out += "</p>";
					}

					out_assignment += out;
				}
				/*segment118-131: ends*/

				out = this.getPartialMarkDetails(instructorQueries, studAnswer);
				//out += this.showFailedDataSets(failedDS,testcon,dbCon,assignment_id,question_id,course_id);

				//Then close the toggling DIV
				out += "</div></div>";
				out_assignment += out;

			}catch (Exception e) {
				logger.log(Level.SEVERE,e.getMessage(),e);
				e.printStackTrace();
			}finally{
				try{
					dbCon.close();
					testcon.close();
				}catch(Exception e){
					e.printStackTrace();	
				}
			}
			//end GSTCRefactor#5
			/*segment105, 107-146 : ends*/ 			
		}

		//out_assignment += "</form></div><!-- End Page Content --></body></html>";
		out_assignment += "</fieldset></div>";
		response.getWriter().write(out_assignment);	

		//out_assignment.close();
		//	session.removeAttribute("dbConn");
		//	session.removeAttribute("testConn");
		//	session.removeAttribute("displayTestCase");

	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}


	/**
	 * This function compares the items in the list and returns required html element
	 * if they are same (with default color  black)/ different(with color red)
	 * 
	 * @param list1
	 * @param list2
	 * @return
	 */
	public String listToString(List<String> list1, List<String> list2){	//whole method is extracted
		String ret = "<ul>";
		for(String s:list1){
			if(list2.contains(s)){
				ret += "<li>" + s + "</li>";
			}else{
				ret += "<li style='color:red;'>" + s + "</li>";
			}		 
		}
		ret += "</ul>";
		return ret;
	}

	/**
	 * Same as previous function, but compares array list of Nodes
	 * @param list1
	 * @param list2
	 * @return
	 */
	public String listToString(ArrayList <Node> list1, ArrayList<Node> list2){	//whole method extracted
		String ret = "<ul>";
		for(Node s:list1){
			if(list2.toString().contains(s.toString())){
				ret += "<li>" + s + "</li>";
			}else{
				ret += "<li style='color:red;'>" + s + "</li>";
			}		 
		}
		ret += "</ul>";
		return ret;
	}
	/**
	 * This method is used to round of marks
	 * @param marks
	 * @return
	 */
	public float roundToDecimal(float marks){
		return BigDecimal.valueOf(marks).setScale(1, BigDecimal.ROUND_HALF_UP).floatValue();
	}
	/**
	 * This method returns a partial mark details string that holds the HTML data to display partail mark details
	 * @param instructorQueries
	 * @param studAnswer
	 * @return
	 */
	public String getPartialMarkDetails(ArrayList <String> instructorQueries, String studAnswer) throws Exception{

		/** taken from PartialMarkDemo Page - Start to show partial mark details for unsaved query **/
		TestPartialMarking testObj=new TestPartialMarking();
		//Call partial mark with instructor and student query and display the details on click of show me! I give up link. Dont toggle
		testObj.StudentQuery=testObj.processCanonicalize(testObj.StudentQuery,1, studAnswer);
		QueryStructure bestInstructorQueryData=null;
		String out = "";	//	Moved here.
		float marks = 0.0f;//belongs to 187-208

		/*segment180,185,187-208 : begins*/	//MAtch~1  /// 4 getPartialMarksAwarded start GSTCRefactor#6			
		String bestInstructorQueryString="";
		int i = 0;
		for(String instQuery:instructorQueries){

			testObj.InstructorQuery=testObj.processCanonicalize(testObj.InstructorQuery,1, instQuery);		
			//Initialize the values
			if(i == 0 ){
				bestInstructorQueryData=testObj.InstructorQuery.getQueryStructure();
				bestInstructorQueryString=instQuery;
			}
			Float studMarks=partialMarking.PartialMarker.calculateScore(testObj.InstructorQuery.getQueryStructure(), testObj.StudentQuery.getQueryStructure(), 0).Marks;
			Float instMarks=partialMarking.PartialMarker.calculateScore(testObj.InstructorQuery.getQueryStructure(), testObj.InstructorQuery.getQueryStructure(), 0).Marks;
			i++;
			Float newMarks=studMarks*100/instMarks;
			if(newMarks> marks){
				marks=newMarks;
				bestInstructorQueryData=testObj.InstructorQuery.getQueryStructure();
				bestInstructorQueryString=instQuery;
			}

		}
		QueryStructure instrData = bestInstructorQueryData;

		//end GSTCRefactor#6		
		/*segement187-208: ends*/		


		QueryStructure studentData = testObj.StudentQuery.getQueryStructure();


		//start refactor ConstructTable		///	start GSTCRefactor#7	

		out += "<div  style='background-color:#FFF'>";
		out +="<br/>";
		out+="<table class='queryTable' width='70%' cellpadding='3' cellspacing='1'><tr>"+
				"<th width='20%'>&nbsp;</th><th width='20%' align='center'>Student</th><th width='20%' align='center'>Instructor</th></tr>";
		/// 4 showComponentDetail	start GSTCRefactor#8
		/*segment210-224 : begins*/				//MAtch~3		

		if( (instrData != null && instrData.getLstRelationInstances().size() > 0)
				|| (studentData != null && studentData.getLstRelationInstances().size() > 0)){
			out += "<tr><td class='emph''>Relations</td>" +
					"<td width=\"20%\">"+listToString(studentData.getLstRelationInstances(),instrData.getLstRelationInstances())+"</td>"+
					"<td width=\"20%\">"+listToString(instrData.getLstRelationInstances(), studentData.getLstRelationInstances())+"</td></tr>";

		}
		/*segment210-224 : ends*/
		//end GSTRefactor#8


		/*segment225-236 : begins*/	//	MAtch~1 /// 4 showComponentDetail start GSTCRefactor#9
		if( (instrData != null && instrData.getLstProjectedCols().size() > 0)
				|| (studentData != null && studentData.getLstProjectedCols().size() > 0)){
			out += "<tr><td class='emph''>Projections</td>" +
					"<td width=\"20%\">"+listToString(studentData.getLstProjectedCols(),instrData.getLstProjectedCols())+"</td>"+
					"<td width=\"20%\">"+listToString(instrData.getLstProjectedCols(), studentData.getLstProjectedCols())+"</td></tr>";

		}
		/*segment225-236 : ends*/		
		//end GSTRefactor#9

		/*segment237-260 : begins*/	//Match~1	///4	Review functionality name is required
		if( (instrData != null && instrData.getIsDistinct())
				|| (studentData != null && studentData.getIsDistinct())){
			/// start GSTCRefactor#10		
			out += "<tr><td class='emph''>Distinct</td>" ;

			int instDistinct = 0;
			int studDistinct = 0;
			if(instrData.getIsDistinct()){
				instDistinct =1;
			}if(studentData.getIsDistinct()){
				studDistinct = 1;
			}
			if(studentData.getIsDistinct() && !instrData.getIsDistinct()){

				out += "<td width=\"20%\" align='center' class=\"number\" style=\"color: red;\">"+studDistinct+"</td>";
			}else{
				out += "<td width=\"20%\" align='center' class='number'>"+studDistinct+"</td>";
			}

			if((instrData.getIsDistinct() && !studentData.getIsDistinct())){
				out += "<td width=\"20%\" align='center' class=\"number\" style=\"color: red;\">"+instDistinct+"</td></tr>";

			}else{
				out += "<td width=\"20%\" align='center' class='number'>"+instDistinct+"</td></tr>";
			}
			//end GSTCRefactor#10		
		}
		/*segment237-260 : ends*/		
		/*segment261-272 : begins*/	//MAtch	/// 4 showComponentDetail	start GSTCRefactor#11
		if( (instrData != null && instrData.getLstGroupByNodes().size() > 0)
				|| (studentData != null && studentData.getLstGroupByNodes().size() > 0)){
			out += "<tr><td class='emph''>Group By</td>" +
					"<td width=\"20%\">"+listToString(studentData.getLstGroupByNodes(),instrData.getLstGroupByNodes())+"</td>"+
					"<td width=\"20%\">"+listToString(instrData.getLstGroupByNodes(), studentData.getLstGroupByNodes())+"</td></tr>";

		}
		//end GSTCRefactor#11			
		/*segment261-272 : ends*/	
		/*segment273-284*/ // MAtch		/// 4 showComponentDetail	start GSTCRefactor#12
		if( (instrData != null && instrData.getLstOrderByNodes().size() > 0)
				|| (studentData != null && studentData.getLstOrderByNodes().size() > 0)){

			out += "<tr><td class='emph''>Order By</td>" +
					"<td width=\"20%\">"+listToString(studentData.getLstOrderByNodes(),instrData.getLstOrderByNodes())+"</td>"+
					"<td width=\"20%\">"+listToString(instrData.getLstOrderByNodes(), studentData.getLstOrderByNodes())+"</td></tr>";
		}
		//end GSTCRefactor#12			
		/*segment273-284 : ends*/	
		/*segment285-296*/	//MAtch	/// 4 showComponentDetail	start GSTCRefactor#13
		if( (instrData != null && instrData.getLstHavingConditions().size() > 0)
				|| (studentData != null && studentData.getLstHavingConditions().size() > 0)){
			out += "<tr><td class='emph''>Having Clause</td>" +
					"<td width=\"20%\">"+listToString(studentData.getLstHavingConditions(),instrData.getLstHavingConditions())+"</td>"+
					"<td width=\"20%\">"+listToString(instrData.getLstHavingConditions(), studentData.getLstHavingConditions())+"</td></tr>";
		}
		/*segment285-296*/
		//end GSTCRefactor#13
		/*segment297-308 : begins*/	//Match	 /// 4 showComponentDetail	start GSTCRefactor#14
		if( (instrData != null && instrData.getLstSubQConnectives().size() > 0)
				|| (studentData != null && studentData.getLstSubQConnectives().size() > 0)){

			out += "<tr><td class='emph''>SubQuery Connectives</td>" +
					"<td width=\"20%\">"+listToString(studentData.getLstSubQConnectives(),instrData.getLstSubQConnectives())+"</td>"+
					"<td width=\"20%\">"+listToString(instrData.getLstSubQConnectives(), studentData.getLstSubQConnectives())+"</td></tr>";
		}
		/*segment297-308*/
		//end GSTCRefactor#14
		/*segment309-320 : begins*/	//MAtch /// 4 showComponentDetail	start GSTCRefactor#15
		if( (instrData != null && instrData.getLstSetOpetators().size() > 0)
				|| (studentData != null && studentData.getLstSetOpetators().size() > 0)){

			out += "<tr><td class='emph''>Set Operators</td>" +
					"<td width=\"20%\">"+listToString(studentData.getLstSetOpetators(),instrData.getLstSetOpetators())+"</td>"+
					"<td width=\"20%\">"+listToString(instrData.getLstSetOpetators(), studentData.getLstSetOpetators())+"</td></tr>";
		}
		/*segment309-320*/	  
		//end GSTCRefactor#15
		/*segment321-334: begins*/		//MAtch~2
		/// 4 showComponentDetail	start GSTCRefactor#16
		if( (instrData != null && instrData.getLstSelectionConditions().size() > 0)
				|| (studentData != null && studentData.getLstSelectionConditions().size() > 0)){

			out += "<tr><td class='emph''>Selection Conditions</td>" +
					"<td width=\"20%\">"+listToString(studentData.getLstSelectionConditions(),instrData.getLstSelectionConditions())+"</td>"+
					"<td width=\"20%\">"+listToString(instrData.getLstSelectionConditions(), studentData.getLstSelectionConditions())+"</td></tr>";


		}
		//end GSTCRefactor#16
		out += "</table></div>";
		//end refactor ConstructTable	end GSTCRefactor#7
		return out;
		/*segment321-334 : ends*/	
	}


	/**
	 * This method is used to show the failed datasets 
	 * 
	 * @param failedDSValues
	 * @param testcon
	 * @param dbCon
	 * @param assignment_id
	 * @param question_id
	 * @param course_id
	 * @return
	 * @throws Exception
	 */
	public String showFailedDataSets(FailedDataSetValues failedDSValues, Connection testcon, Connection dbCon, int assignment_id, 
			int question_id, String course_id) throws Exception{
		//segment: Remaining whole method almost	//Notmatch
		String out_assignment = "";
		String sel_dataset = "select tag,value from xdata_datasetvalue where datasetid =? and assignment_id= ? and question_id=? and query_id=?";
		//logger.log(Level.FINE,"Ans : "+ ans);
		out_assignment += "<h3>"+"Your query did not match the following datasets."+"</h3><hr>";
		PopulateTestDataGrading populateTestData = new PopulateTestDataGrading();
		populateTestData.deleteAllTempTablesFromTestUser(testcon);
		populateTestData.createTempTables(testcon, assignment_id, question_id);

		//while(setIterator.hasNext()){
		for(int ds=0;ds<failedDSValues.getDataSetIdList().size();ds++){
			//String dataSetId = setIterator.next();
			String dataSetId = failedDSValues.getDataSetIdList().get(ds);
			logger.log(Level.FINE,"Data st IDs = "+dataSetId);

			/*segment349-371:begins*///NotMAtch /// 4 getDatasets		
			//start refactor getDatasets 	start GSTCRefactor#17	
			try(PreparedStatement stmt2=dbCon.prepareStatement(sel_dataset)){
				stmt2.setString(1, dataSetId);
				stmt2.setInt(2,assignment_id); 
				stmt2.setInt(3,question_id);
				stmt2.setInt(4,1); 
				if(dataSetId.startsWith("DS")){
					//If it is dataset generated by XData

					/*segment357-363:begins*/ /// 2		//Notmatch
					try(ResultSet resultSet1 = stmt2.executeQuery()){ 
						if(resultSet1.next()){				 
							out_assignment += "<div style='align:left;'><h4>"+resultSet1.getString("tag")+"</h4>";
							out_assignment += "</div>";
						}
					}
					/*segment357-363:ends*/		

				}
				//If the DataSet is not generated, then show sample data
				else{
					out_assignment += "<div style='align:left;'><h4>Default sample data Id:"+dataSetId+"</h4>";
					out_assignment += "</div>";
				}
			}
			//end GSTCRefactor#17		
			out_assignment += "";
			out_assignment +="<div style='margin-right: 40%;'>";
			out_assignment += "<span> <b>Your Result</b></span>";
			out_assignment += "<table border=\"1\">";
			out_assignment += "<tr>";

			/*segment349-371:ends*/	     
			Map<String, ArrayList<String>> studDataFailed = failedDSValues.getStudentQueryOutput().get(dataSetId);
			Iterator it = studDataFailed.keySet().iterator();
			while(it.hasNext()){ 
				out_assignment += "<th>"+ (String)it.next()+"</th>";			    	 
			}
			out_assignment += "</tr>";
			it = studDataFailed.keySet().iterator();

			///start refactor  4 getFailedDataset  start GSTCRefactor#18 
			int colSize = studDataFailed.keySet().size();
			int valSize = 0;
			out_assignment += "<tr>";

			/*segment387-392:begin*/ 	//Notmatch
			while(it.hasNext()){
				int valCnt = 0;
				ArrayList Values = studDataFailed.get(it.next());
				valSize = Values.size();
			}
			/*segment387-392:ends*/

			if(valSize== 0){
				while(it.hasNext()){
					out_assignment += "<td></td>";
				}
				out_assignment += "</tr>";
			}else{
				for(int v = 0 ; v< valSize;v++){
					it = studDataFailed.keySet().iterator();
					/*segment403-410:begin*/	 //Notmatched
					while(it.hasNext()){
						int valCnt = 0;
						ArrayList Values = studDataFailed.get(it.next());
						out_assignment += "<td>"+Values.get(v)+"</td>";
					}
					out_assignment += "</tr>";
					/*segment403-410:ends*/	     
				}
			}
			//end #GSTCRefactor#18  

			out_assignment += "</table>";
			out_assignment += "</div>";
			out_assignment += "<p></p>";
			/**    SHOW EXPECTED RESULT    **/
			out_assignment += "<div style='margin-right: 20%;'>";
			out_assignment += "<span><b> Expected Result</b></span>";
			out_assignment += "<table border=\"1\">";
			out_assignment += "<tr>";
			Map<String, ArrayList<String>> instrDataFailed = failedDSValues.getInstrQueryOutput().get(dataSetId);
			Iterator it1 = instrDataFailed.keySet().iterator();
			while(it1.hasNext()){ 
				out_assignment += "<th>"+ (String)it1.next()+"</th>";			    	 
			}
			out_assignment += "</tr>";
			it1 = instrDataFailed.keySet().iterator();
			int colSize1 = instrDataFailed.keySet().size();

			///start refactor  4 getFailedDataset	#start GSTCRefactor#19			
			int valSize1 = 0;
			out_assignment += "<tr>";


			/*segment434-439:begins*/ 	//Notmatched
			while(it1.hasNext()){
				int valCnt = 0;
				ArrayList Values = instrDataFailed.get(it1.next());
				valSize1 = Values.size();
			}
			/*segment434-439:ends*/	     
			if(valSize1 == 0){
				while(it1.hasNext()){
					out_assignment += "<td></td>";
				} 
				out_assignment += "</tr>";
			}else{
				for(int v = 0 ; v< valSize1;v++){
					it1 = instrDataFailed.keySet().iterator();
					/*segment450-456:begins*/ // Notmatched
					while(it1.hasNext()){						    	
						ArrayList Values = instrDataFailed.get(it1.next());
						out_assignment += "<td>"+Values.get(v)+"</td>";
					}
					out_assignment += "</tr>"; 
					/*segment450-456: ends*/     
				}

			}

			//end #GSTCRefactor#19	     
			out_assignment += "</table>";
			out_assignment += "</div>";
			out_assignment += "<p></p>";
			//Select and show the  datasets
			if(dataSetId.startsWith("DS")){
				try(PreparedStatement pstmt=dbCon.prepareStatement("select value from xdata_datasetvalue where assignment_id=? and question_id = ? and datasetid=? and course_id = ?")){
					pstmt.setInt(1, assignment_id);
					pstmt.setInt(2,question_id);
					pstmt.setString(3,dataSetId);
					pstmt.setString(4,course_id);
					try(ResultSet rsi=pstmt.executeQuery()){
						while(rsi.next()){
							String value=rsi.getString("value");
							//It holds JSON obj tat has list of Datasetvalue class
							Gson gson = new Gson();
							//ArrayList dsList = gson.fromJson(value,ArrayList.class);
							Type listType = new TypeToken<ArrayList<DataSetValue>>() {}.getType();

							List<DataSetValue> dsList = new Gson().fromJson(value, listType);	

							out_assignment += "<div style='margin-right: 20%;'>";
							out_assignment += "<a class='showhidelink' href = 'javascript:void(0);' onclick=\"toggleDataset('#"+dataSetId+"')\">View Dataset</a>";
							out_assignment += "<div class='detail' id='"+dataSetId+"'>";//part of 481-520
							boolean refTableExists = false;

							/*segment481-520 : begins*/	//MAtch	/// 4 showTable	start GSTCRefactor#20

							for(int i = 0 ; i < dsList.size();i++ ){
								DataSetValue dsValue = dsList.get(i);
								String tname = "",values;

								if(dsValue.getFilename().contains(".ref")){
									refTableExists = true;
								}
								if(!(dsValue.getFilename().contains(".ref"))){
									tname = dsValue.getFilename().substring(0,dsValue.getFilename().indexOf(".copy"));

									//tname = dsValue.getFilename().substring(0,dsValue.getFilename().indexOf(".copy"));
									PreparedStatement detailStmt = testcon.prepareStatement("select * from " + tname + " where 1 = 0");
									ResultSetMetaData columnDetail = detailStmt.executeQuery().getMetaData();
									out_assignment += "<table border=\"1\">";

									/*segment501-508 : begins*/	//MAtch	/// 4 displayColName	start GSTCRefactor#21
									out_assignment += "<caption>"+tname+"</caption>";
									out_assignment +="<tr>";
									//Column names get from metadata
									for(int cl=1; cl <= columnDetail.getColumnCount(); cl++)
									{
										out_assignment += "<th>" + columnDetail.getColumnLabel(cl)+"</th>";
									} 
									out_assignment += "</tr>";
									/*segment501-508 : ends*/	
									//end #GSTCRefactor#21
									/*segment509-518 : begins*/	//MAtch		/// 4 displayColValue start #GSTCRefactor#22
									//Get Column values
									for(String dsv: dsValue.getDataForColumn()){
										String columns[]=dsv.split("\\|");
										out_assignment += "<tr>";
										for(String column: columns)
										{
											out_assignment += "<td>"+column+"</td>";
										}
										out_assignment += "</tr>";
									}
									/*segment509-518 : ends*/	
									//end #GSTCRefactor#22	
									detailStmt.close();
								} 
							}
							/*segment481-520 : ends*/	
							//end #GSTCRefactor#20	

							/*segment521-567 : begins*/	//MAtch		/// 4 showReferenceTable start GSTCRefactor#23
							out_assignment += "</table>";
							out_assignment += "<p></p>";

							//***To show referenced tables
							/**Code to toggle Reference Tables **/
							if(refTableExists){

								out_assignment += "<p></p><div style='margin-right: 0%;'>";
								out_assignment += "<a class='showhidelink' href = 'javascript:void(0);' onclick=\"toggleRefTables('#"+failedDSValues.getQuery_id()+"R"+dataSetId+"')\">View Referenced Tables</a>";

								out_assignment += "<p></p><div class='detail' id='"+failedDSValues.getQuery_id()+"R"+dataSetId+"'>";
								//start GSTCRefactor#24 showTable	4	
								for(int i = 0 ; i < dsList.size();i++ ){ 
									DataSetValue dsValue = dsList.get(i);
									String tname = "",values;
									//if(dsValue.getFilename().contains(".ref")){
									//	tname = dsValue.getFilename().substring(0,dsValue.getFilename().indexOf(".ref"));
									//}
									if(dsValue.getFilename().contains(".ref")){
										tname = dsValue.getFilename().substring(0,dsValue.getFilename().indexOf(".ref"));

										PreparedStatement detailStmt = testcon.prepareStatement("select * from " + tname + " where 1 = 0");
										ResultSetMetaData columnDetail = detailStmt.executeQuery().getMetaData();

										out_assignment += "<table border=\"1\">";
										/*segment545-552 : begins*/	//MAtch~1	/// 4 displayColName	start GSTCRefactor#25
										out_assignment += "<caption>"+tname+"</caption>";
										out_assignment += "<tr>";
										//Column names get from metadata
										for(int cl=1; cl <= columnDetail.getColumnCount(); cl++)
										{
											out_assignment += "<th>"+columnDetail.getColumnLabel(cl)+"</th>";
										}
										out_assignment += "</tr>";//
										//end GSTCRefactor#25		 
										/*segment545-552 : ends*/			  
										/*segment553-562 : begins*/	//MAtch~1	/// 4 displayColValue	start GSTCRefactor#26

										//Get Column values
										for(String dsv: dsValue.getDataForColumn()){
											String columns[]=dsv.split("\\|");
											out_assignment += "<tr>";
											for(String column: columns)
											{
												out_assignment += "<td>"+column+"</td>";
											}
											out_assignment += "</tr>";
										}													
										out_assignment += "</table>";
										//end GSTCRefactor#26		 
										/*segment553-562 : ends*/
										detailStmt.close();
									}
								}
								//end GSTCRefactor#24
								out_assignment +="</div></div>";
							}
							out_assignment += "</div></div>";

							//end GSTCRefactor#23				
							/*segment521-567 : ends*/			
						}
						//out_assignment += "</div></div>";
					}//rsi ends
				}//pstmt ends
			} else{
				//If dsId is sampledataId, then show sample data as tables
				out_assignment += "<div style='margin-right: 20%;'>";
				out_assignment += "<a class='showhidelink' href = 'javascript:void(0);' onclick=\"toggleDataset('#"+dataSetId+"')\">View Dataset</a>";

				out_assignment += "<div class='detail' id='"+dataSetId+"'>";//included in 580-615

				populateTestData.deleteAllTablesFromTestUser(testcon);
				populateTestData.createTempTableWithDefaultData(dbCon, testcon, assignment_id, question_id, course_id, dataSetId);			    	 
				PreparedStatement p1 = testcon.prepareStatement("drop table if exists DATASET");
				p1.execute();

				DatabaseMetaData meta = testcon.getMetaData();
				/// 4 showDataset start GSTCRefactor#27
				String tableFilter[] = {"TEMPORARY TABLE"};
				ResultSet r = meta.getTables(dbCon.getCatalog(), "", "%", tableFilter);        
				/*segment580-615 : begins*/  	//MAtch~2
				while (r.next()) {                          
					String tableName = r.getString("TABLE_NAME").toUpperCase();
					System.out.println("Table : "+ tableName);
					if(!tableName.equalsIgnoreCase("dataset")){ 
						PreparedStatement p = testcon.prepareStatement("select * from "+tableName);

						ResultSetMetaData columnDetail = p.executeQuery().getMetaData();
						out_assignment += "<table border=\"1\">";
						/*segment591-598 : begins*/ /// 4 displayColName start GSTCRefactor#28			//MAtch~1
						out_assignment += "<caption>"+tableName+"</caption>";
						out_assignment += "<tr>";
						//Column names get from metadata
						for(int cl=1; cl <= columnDetail.getColumnCount(); cl++)
						{
							out_assignment += "<th>" + columnDetail.getColumnLabel(cl)+"</th>";
						} 
						out_assignment +="</tr>";//part of 603-612	
						//	end GSTCRefactor#28
						/*segment591-598 : ends*/				

						ResultSetMetaData columnDetail1 = p.executeQuery().getMetaData();//part of 603-612
						ResultSet rrset = p.executeQuery();
						/*segment603-612 : begins*/ /// 4 displayColValue	start GSTCRefactor#29		//MAtch~1
						while(rrset.next()){
							out_assignment += "<tr>";
							for(int cl=1; cl <= columnDetail1.getColumnCount(); cl++)
							{	
								out_assignment += "<td>"+rrset.getString(cl)+"</td>";
							}
							out_assignment += "</tr>";
						}
						// end GSTCRefactor#29			 
						/*segment603-612 : ends*/			 
					}
					out_assignment += "</table>";
					out_assignment += "<p></p>";	
				}

				out_assignment += "</div></div>";
				/// end GSTCRefactor#27        
				/*segment580-615 : ends*/          
			}			     
			out_assignment += "<hr>";
			//out_assignment += "</div>";
		}

		out_assignment += "</div></div>";
		out_assignment += "<p></p>";					 
		//out_assignment += "<hr>";

		return out_assignment;
	}





	/**
	 * This method is used to show the passed datasets for guest user 
	 * 
	 * @param failedDSValues
	 * @param testcon
	 * @param dbCon
	 * @param assignment_id
	 * @param question_id
	 * @param course_id
	 * @return
	 * @throws Exception
	 */
	public String showPassedDataSets(FailedDataSetValues failedDSValues, Connection testcon, Connection dbCon, int assignment_id, 
			int question_id, String course_id) throws Exception{

		String out_assignment = "";
		String sel_dataset = "select tag,value,datasetid from xdata_datasetvalue where course_id=? and assignment_id= ? and question_id=? and query_id=?";
		//logger.log(Level.FINE,"Ans : "+ ans);
		out_assignment += "<a name='passedDataSets'></a><div id=\"ShowPassedDataSets\" style='display:none;'><h3>"+"Your query matches the following datasets."+"</h3>";
		out_assignment +="<hr>";
		PopulateTestDataGrading populateTestData = new PopulateTestDataGrading();
		populateTestData.deleteAllTempTablesFromTestUser(testcon);
		populateTestData.createTempTables(testcon, assignment_id, question_id);

		ArrayList <String> failedDataSets = failedDSValues.getDataSetIdList();
		try(PreparedStatement stmt2=dbCon.prepareStatement(sel_dataset)){
			stmt2.setString(1, course_id);
			stmt2.setInt(2,assignment_id); 
			stmt2.setInt(3,question_id);
			stmt2.setInt(4,1); 

			//If it is dataset generated by XData
			try(ResultSet resultSet1 = stmt2.executeQuery()){ 
				while(resultSet1.next()){				 

					String dataSetId = resultSet1.getString("datasetid");
					boolean refTableExists = false;
					//When DataSet is not in Failed DataSet List
					if(!failedDataSets.contains(dataSetId)){
						//GSTCRefactor#30 starts			
						/*segment645-693: begins*/	/// 4 showResult		//MAtch
						out_assignment += "<div style='align:left;'><h4>"+resultSet1.getString("tag")+"</h4>";
						out_assignment += "</div>";

						String value=resultSet1.getString("value");
						//It holds JSON obj tat has list of Datasetvalue class
						Gson gson = new Gson();
						//ArrayList dsList = gson.fromJson(value,ArrayList.class);
						Type listType = new TypeToken<ArrayList<DataSetValue>>() {}.getType();

						List<DataSetValue> dsList = new Gson().fromJson(value, listType);	
						for(int i = 0 ; i < dsList.size();i++ ){

							DataSetValue dsValue = dsList.get(i);

							out_assignment += "<div >";
							String tname = "",values;

							if(dsValue.getFilename().contains(".ref")){
								refTableExists = true;
							}
							if(!(dsValue.getFilename().contains(".ref"))){
								tname = dsValue.getFilename().substring(0,dsValue.getFilename().indexOf(".copy"));

								//tname = dsValue.getFilename().substring(0,dsValue.getFilename().indexOf(".copy"));
								PreparedStatement detailStmt = testcon.prepareStatement("select * from " + tname + " where 1 = 0");
								ResultSetMetaData columnDetail = detailStmt.executeQuery().getMetaData();
								out_assignment += "<table border=\"1\">";
								//GSTCRefactor#31 starts		
								out_assignment += "<caption>"+tname+"</caption>";
								out_assignment +="<tr>";
								//Column names get from metadata
								for(int cl=1; cl <= columnDetail.getColumnCount(); cl++)
								{
									out_assignment += "<th>" + columnDetail.getColumnLabel(cl)+"</th>";
								} 
								//GSTCRefactor#31 ends
								//GSTCRefactor#32 starts			
								out_assignment += "</tr>";
								//Get Column values
								for(String dsv: dsValue.getDataForColumn()){
									String columns[]=dsv.split("\\|");
									out_assignment += "<tr>";
									for(String column: columns)
									{
										out_assignment += "<td>"+column+"</td>";
									}
									out_assignment += "</tr>";
								}
								out_assignment += "</table>";
								//GSTCRefactor#32 ends							
								detailStmt.close();
							} 

							out_assignment += "<p></p>";

						}
						/*segment645-693: ends*/		
						//GSTCRefactor#30 ends					
						//***To show referenced tables
						/**Code to toggle Reference Tables **/
						//GSTCRefactor#33 starts			
						/*segment694-738:begins*/		/// 4 getRefTable		//MAtch
						if(refTableExists){

							out_assignment += "<p></p><div >";
							out_assignment += "<a class='showhidelink' href = 'javascript:void(0);' onclick=\"toggleRefTables('#"+failedDSValues.getQuery_id()+"R"+dataSetId+"')\">View Referenced Tables</a>";

							out_assignment += "<p></p><div class='detail' id='"+failedDSValues.getQuery_id()+"R"+dataSetId+"'>";

							for(int i = 0 ; i < dsList.size();i++ ){ 
								DataSetValue dsValue = dsList.get(i);
								String tname = "",values;

								if(dsValue.getFilename().contains(".ref")){
									tname = dsValue.getFilename().substring(0,dsValue.getFilename().indexOf(".ref"));

									PreparedStatement detailStmt = testcon.prepareStatement("select * from " + tname + " where 1 = 0");
									ResultSetMetaData columnDetail = detailStmt.executeQuery().getMetaData();

									out_assignment += "<table border=\"1\">";
									//GSTCRefactor#34 starts						
									/*segment716-723:begins*/	 /// 4 displayColName		//Should be match with one missing stmt (just above one)
									out_assignment += "<caption>"+tname+"</caption>";
									out_assignment += "<tr>";
									//Column names get from metadata
									for(int cl=1; cl <= columnDetail.getColumnCount(); cl++)
									{
										out_assignment += "<th>"+columnDetail.getColumnLabel(cl)+"</th>";
									} 
									/*segment716-723:ends*/				
									//GSTCRefactor#34 ends			
									//GSTCRefactor#35 starts
									/*segment724-735:begins*/	/// 4 displayColValue			//MAtch		
									out_assignment += "</tr>";
									//Get Column values
									for(String dsv: dsValue.getDataForColumn()){
										String columns[]=dsv.split("\\|");
										out_assignment += "<tr>";
										for(String column: columns)
										{
											out_assignment += "<td>"+column+"</td>";
										}
										out_assignment += "</tr>";
									}		
									/*segment724-735:ends*/			
									//GSTCRefactor#35 ends																				
									detailStmt.close();
									out_assignment += "</table>";//belongs to segment724-735

								}
							}
							out_assignment +="</div></div>";
						}
						out_assignment += "</div><hr>";
						/*segment694-738:ends*/
						//GSTCRefactor#33 ends							

					}
				}
			}

		}
		out_assignment += "</div>"; 
		return out_assignment;
	}
}
